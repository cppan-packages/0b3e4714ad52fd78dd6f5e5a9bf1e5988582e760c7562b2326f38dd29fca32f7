//  Copyright 2017 Francois Chabot
//  (francois.chabot.dev@gmail.com)
//
//  Distributed under the Boost Software License, Version 1.0.
//  (See accompanying file LICENSE or copy at
//  http://www.boost.org/LICENSE_1_0.txt)

#ifndef ABULAFIA_CONFIG_H_
#define ABULAFIA_CONFIG_H_

#ifndef ABULAFIA_NAMESPACE
#define ABULAFIA_NAMESPACE abu
#endif

#endif
